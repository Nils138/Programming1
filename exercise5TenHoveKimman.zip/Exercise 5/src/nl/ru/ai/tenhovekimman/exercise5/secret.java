package nl.ru.ai.tenhovekimman.exercise5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Random;

public class secret {
	/**
	 * The character encrypted or decrypted with a random number
	 * @param input
	 * @param random
	 * @param encrypt
	 * @return output
	 */
	public static char crypt(char input, int random) {
		assert true;
		int output = input;
		if (input<=127 && input>=32)
			output = (input - 32 - random + 96) % 96 + 32;
		return (char) output;
	}
	/**
	 * Reads and encrypts/decrypts given input file based on given boolean, calls function to write encryption/decryption in given outputFile
	 * @param inputFile
	 * @param encryption
	 * @param outputFile
	 * @throws IOException
	 */
	public static boolean english(int cryptC) {		
		return (cryptC >= 32 && cryptC <=35) || cryptC == 38 || (cryptC >=39 && cryptC <= 46) || (cryptC >=48 && cryptC <=59) || cryptC == 63 || (cryptC >=65 && cryptC <= 125);
	}
	public static void readFile(String inputFile, String outputFile) throws IOException {
		InputStreamReader reader;
		reader = new InputStreamReader(new FileInputStream(inputFile));
		String output = "";
		boolean done = false;
		int done2 = 0;
		for (int i = 0; i <= 12350; i++) {
			System.out.println(i);
			Random generator = new Random(i);
			int c;
			int cryptC = 32;
			while ((c = reader.read()) >= 0 || english(cryptC) || cryptC == c) {
				System.out.println(c);
				System.out.println(cryptC);
				cryptC = (int)crypt((char)c, generator.nextInt(96));
			}
			if (!(english(cryptC) && cryptC == c)) {
				System.out.println((char)cryptC);
			}
		}
		if (done) {
			System.out.println("Hurray");
			System.out.println(done2);
		}
		writeFile(output);
		reader.close();
	}
	/**
	 * Writes given input in given output file
	 * @param input
	 * @param outputFile
	 * @throws IOException
	 */
	public static void writeFile(String input) throws IOException {
		assert true;
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("englishNovel.txt"));
		writer.write(input);
		writer.close();
	}
	/**
	 * Opens a scanner and calls functions to ask the user for an input file, an encryption type, and an output file, and it calls a function which reads the input file.
	 * @param args
	 */
	public static void main(String[] args) {
		assert true;	
		try {
			readFile("secret.txt", "englishNovel.txt");
		} catch (IOException e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}
	}
}
