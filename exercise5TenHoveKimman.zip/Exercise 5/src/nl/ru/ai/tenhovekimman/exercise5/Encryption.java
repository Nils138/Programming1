package nl.ru.ai.tenhovekimman.exercise5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Random;
import java.util.Scanner;

public class Encryption {
	/**
	 * The character encrypted or decrypted with a random number
	 * @param input
	 * @param random
	 * @param encrypt
	 * @return output
	 */
	public static char crypt(char input, int random, boolean encrypt) {
		assert true;
		int output = input;
		if (input<=127 && input>=32) {
			if (encrypt) {
				output = (input - 32 + random + 96) % 96 + 32;
			} else {
				output = (input - 32 - random + 96) % 96 + 32;
			}
		}
		return (char) output;
	}
	/**
	 * Makes a list of all the character with unicode number 32 to 127, their encryption, and that decryption
	 */
	public static void exercise1() {
		assert true;
		for (int i = 32; i <= 127; i++) {
			System.out.print((char) i);
			char encryption = crypt((char) i, 42, true);
			System.out.print(encryption);
			System.out.println(crypt(encryption, 42, false));
		}
	}
	/**
	 * Reads and encrypts/decrypts given input file based on given boolean, calls function to write encryption/decryption in given outputFile
	 * @param inputFile
	 * @param encryption
	 * @param outputFile
	 * @throws IOException
	 */
	public static void readFile(String inputFile, boolean encryption, String outputFile) throws IOException {
		assert true;
		Random generator = new Random(4711);
		InputStreamReader reader;;
		reader = new InputStreamReader(new FileInputStream(inputFile));
		int c;
		String output = "";
		while ((c = reader.read()) >= 0) {
			output = output + crypt((char)c, generator.nextInt(96), encryption);
		}
		writeFile(output, outputFile);
		reader.close();
	}
	/**
	 * Writes given input in given output file
	 * @param input
	 * @param outputFile
	 * @throws IOException
	 */
	public static void writeFile(String input, String outputFile) throws IOException {
		assert true;
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(outputFile));
		writer.write(input);
		writer.close();
	}
	/**
	 * Gets the name for the input file from the user
	 * @param scanner
	 * @return inputFile
	 */
	public static String inputFile(Scanner scanner) {
		assert true;
		System.out.println("Enter an input file name:");
		String inputFile = scanner.next();
		return inputFile;
	}
	/**
	 * Gets the boolean for encryption from the user
	 * @param scanner
	 * @return encryption
	 */
	public static Boolean encryption(Scanner scanner) {
		assert true;
		System.out.println("Type 'true' for encryption, 'false' for decryption:");
		Boolean encryption = scanner.nextBoolean();
		return encryption;
	}
	/**
	 * Gets the name for the output file from the uesr
	 * @param scanner
	 * @return outputFile
	 */
	public static String outputFile(Scanner scanner) {
		assert true;
		System.out.println("Enter output file name:");
		String outputFile = scanner.next();
		return outputFile;
	}
	/**
	 * Opens a scanner and calls functions to ask the user for an input file, an encryption type, and an output file, and it calls a function which reads the input file.
	 * @param args
	 */
	public static void main(String[] args) {
		exercise1();
		assert true;
		Scanner scanner = new Scanner(System.in);
		try {
			readFile(inputFile(scanner), encryption(scanner), outputFile(scanner));
		} catch (IOException e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}
		scanner.close();
	}
}
