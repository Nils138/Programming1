package nl.ru.ai.exercise6;

import nl.ru.ai.gameoflife.Cell;
import static nl.ru.ai.gameoflife.Universe.*;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class GameOfLife {
	/**
	 * Asks user for inputfile, the amount of generations, whether to save the outcome into a file and if so it asks for the file name, then it checks if the input file exists, then goes through all generations of the game of life and possibly saves the outcome to a file
	 * @param args
	 */
	public static void main(String[] args) {
		assert true;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input file");
		String inputFile = scanner.next();
		System.out.println("Enter the amount of generations:");
		int generations = scanner.nextInt();
		System.out.println("Enter 'true' to save outcome into file, false if otherwise:");
		boolean writeFile = scanner.nextBoolean();
		String outputFile = "";
		if (writeFile) {
			System.out.println("Enter the outputfile name:");
			outputFile = scanner.next();
		}
		Cell[][] universe;
		try {
			universe = readUniverseFile(inputFile);
			cycleUniverse(universe, generations, writeFile, outputFile);
		} catch (IOException e) {
			System.out.println("The inputfile does not exist");
			e.printStackTrace();
		}
		scanner.close();
	}
	/**
	 * Takes the specified array and writes it into a 40 x 60 grid in an outputfile with a given name
	 * @param universe
	 * @param outputFile
	 * @throws IOException
	 */
	
	public static void writeUniversetoFile(Cell[][] universe, String outputFile) throws IOException {
		assert (outputFile !="" && universe != null):"Invalid input";
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(outputFile));
		writer.write(fillFile(universe));
		writer.close();
	}
	
	/**
	 * loops through all positions in the given array and fills makes an output accordingly (with .'s and *'s)
	 * @param universe
	 * @return output
	 */
	
	public static String fillFile(Cell[][] universe) {
		assert (universe != null):"Array does not exist";
		String output = "";
		for (int i = 0; i < universe.length; i++) {
			for (int j = 0; j < universe[i].length; j++) {
				if (universe[i][j] == Cell.LIVE) 
					output += "*";
				else
					output += ".";
			}
			if (i != universe.length-1)
				output += "\n";
		}
		return output;
	}
	
	/**
	 * Repeats the following steps: show the current universe, change universe to next generation, wait 0,2 seconds
	 * @param universe
	 * @throws IOException 
 	*/
	public static void cycleUniverse(Cell[][] universe, int generations, boolean writeFile, String outputFile) throws IOException {
		assert (universe != null) : "Array does not exist";
		while (generations > 0) {
				showUniverse(universe);
				universe = nextGeneration(universe);
				sleep(100);
				generations--;
			}
		if (writeFile)
			writeUniversetoFile(universe, outputFile);
	}
	/**
	 * Fills the specified array with dead cells
	 * @param universe
	 */
	public static void fillArray(Cell[][] universe) {
		assert (universe.length > 0) : "Array length is not positive";
		for (int i = 0; i < universe.length; i++) {
			for (int j = 0; j < universe[i].length; j++) {
				universe[i][j] = Cell.DEAD;
			}
		}
	}
	
	/**
	 * Changes cells in the specified universe to live
	 * @param j
	 * @param i
	 * @param universe
	 * @throws IOException
	 */
	
	public static void liveCells(int j, int i, Cell[][] universe) throws IOException {
		assert (j != 0 && j != 59 && i != 0 && i != 39): "The inputfile has a live cell on its border";
		universe [i][j] = Cell.LIVE;
	}
	
	/**
	 * loops through each character in the line and changes cells in the array based on the input from the reader
	 * @param c
	 * @param i
	 * @param universe
	 * @throws IOException
	 */
	
	public static void lineLoop(int j, int c, int i, Cell[][] universe) throws IOException{
		assert (c == 46 || c == 42 || c == 13 || c == 10): "Invalid character in the file";
			if (c == 46){
				universe[i][j] = Cell.DEAD;
			}else if (c == 42){
				liveCells(j, i, universe);
			}
	}
	
	/**
	 * Checks if the inputfile has 60 columns and 40 rows, then calls loopLine for each position in the field.
	 * @param position
	 * @param universe
	 * @param line
	 * @param bufferedReader
	 * @param i
	 * @param reader
	 * @return universe, or null if the inputfile does not have 40 rows
	 * @throws IOException
	 */
	
	public static Cell[][] readFile(int position, Cell[][] universe, String line, BufferedReader bufferedReader, int i, InputStreamReader reader) throws IOException {
		assert true;
		while ((line = bufferedReader.readLine()) != null) {
			if (line.length()!= 60) 
				throw new IllegalArgumentException("The inputfile has a line which does not contain 60 characters");
			for (int j = 0; j < 60; j++) {
				position = reader.read();
				lineLoop(j, position, i, universe);
			}
			i++;
			reader.read();
			reader.read(); //these skip the enter
		}
		if (i != 40) 
			throw new IllegalArgumentException("The inputfile does not have 40 rows");
		return universe;
	}
	/**
	 * Initializes a lot of variables then reads the inputfile and stores its information into universe
	 * @param fileName
	 * @return universe
	 * @throws IOException
	 */
	
	static Cell[][] readUniverseFile(String fileName) throws IOException {
		assert (fileName != ""):"inputfile does not exist";
		Cell[][] universe = new Cell[40][60];
		fillArray(universe);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		InputStreamReader reader = new InputStreamReader(new FileInputStream(fileName));
		int c = 0;
		String d = "";
		int i = 0;
		readFile(c, universe, d, bufferedReader, i,  reader);
		bufferedReader.close();
		reader.close();
		return universe;
	}
	
	/**
	 * Updates the screen for each position in universe
	 * @param universe
	 */

	private static void showUniverse(Cell[][] universe) {
		assert (universe != null): "Array does not exist";
		for (int i = 0; i < universe.length; i++) {
			for (int j = 0; j < universe[i].length; j++) {
				updateScreen(i, j, universe[i][j]);
			}
		}
	}
	
	/**
	 * checks if the given position in the array has a neighbour
	 * @param universe
	 * @param i
	 * @param j
	 * @return 1 if the position has a neighbour, 0 if it doesn't
	 */
	
	public static int checkNeighbours(Cell[][] universe, int i, int j) {
		assert (universe != null):"Array does not exist";
		if (i >=0 && i <= 39 && j >= 0 && j <= 59) {
			if (universe[i][j] == Cell.LIVE)
				return 1;
			else
				return 0;
		}else 
			return 0;
	}
	
	/**
	 * Checks how many neighbours the given cell has
	 * @param universe
	 * @param i
	 * @param j
	 * @return the amount of neighbours the specified cell has
	 */
	
	private static int Neighbours(Cell[][] universe, int i, int j) {
		assert (universe != null): "Array does not exist";
		if (i != 0 && j!= 0 && i != 39 && j != 59) {
			int neighbours = 0; 
			neighbours += checkNeighbours(universe, i+1, j); // couldn't find a nice way to do this :(
			neighbours += checkNeighbours(universe, i-1, j);
			neighbours += checkNeighbours(universe, i, j+1);
			neighbours += checkNeighbours(universe, i, j-1);
			neighbours += checkNeighbours(universe, i+1, j+1);
			neighbours += checkNeighbours(universe, i+1, j-1);
			neighbours += checkNeighbours(universe, i-1, j+1);
			neighbours += checkNeighbours(universe, i-1, j-1);
			return neighbours;
		}else {
			return 0;
		}
	}
	
	/**
	 * Kills cells if there's underpopulation or overpopulation, let's them live if there is none
	 * @param universe
	 * @param alternateUniverse
	 * @param i
	 * @param j
	 */
	
	public static void killCells(Cell[][] universe, Cell[][] alternateUniverse, int i, int j) {
		assert (universe != null && alternateUniverse != null):"Array(s) do(es) not exist";
		if (Neighbours(universe, i, j) < 2) {
			alternateUniverse[i][j] = Cell.DEAD;
		}else if (Neighbours(universe, i, j) > 3) {
			alternateUniverse[i][j] = Cell.DEAD;
		}else {
			alternateUniverse[i][j] = Cell.LIVE;
		}
	}
	
	/**
	 * Calls the judge for live cells if they get to keep living, brings dead cells back to life if they have 3 neighbours
	 * @param universe
	 * @param i
	 * @param j
	 * @param alternateUniverse
	 */
	
	public static void changeUniverse(Cell[][] universe, int i, int j, Cell[][] alternateUniverse) {
		assert (universe != null && alternateUniverse != null):"Array(s) do(es) not exist";
		if (universe[i][j] == Cell.DEAD) {
			if (Neighbours(universe, i, j) == 3) {
				alternateUniverse[i][j] = Cell.LIVE;
			}
		}else {
			killCells(universe, alternateUniverse, i, j);
		}
	}
	
	/**
	 * Creates an alternate universe and fills it, then it copies the next generation from the old universe into the new universe
	 * @param universe
	 * @return alternateUniverse
	 */

	private static Cell[][] nextGeneration(Cell[][] universe) {
		assert (universe != null): "Array does not exist";
		Cell[][] alternateUniverse = new Cell[40][60];
		fillArray(alternateUniverse);
		for (int i = 0; i < universe.length; i++) {
			for (int j = 0; j < universe[i].length; j++) {
				changeUniverse(universe, i, j, alternateUniverse);
			}
		}
		return alternateUniverse;
	}
}
