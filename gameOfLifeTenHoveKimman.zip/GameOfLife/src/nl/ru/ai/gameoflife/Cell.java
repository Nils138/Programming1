package nl.ru.ai.gameoflife;

public enum Cell {
  DEAD, LIVE
}
