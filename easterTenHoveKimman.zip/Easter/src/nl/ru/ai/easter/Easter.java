package nl.ru.ai.easter;

import java.util.Scanner;

public class Easter {
	static boolean isLeapYear(int year) {
		return (year % 4 == 0 && !(year % 100 == 0) || year % 400 == 0);
	}

	static int numberOfDaysInMonth(int year, Month month) {
		int daysInMonth = 0;
		switch (month) {
			case APRIL: case JUNE: case SEPTEMBER: case NOVEMBER:
				daysInMonth = 30;
			break;
			case FEBRUARY:
				if (isLeapYear(year)) {
					daysInMonth = 29;
				} else
					daysInMonth = 28;
			break;
			default:
				daysInMonth = 31;
			break;
		}
		return daysInMonth;
	}

	static Month easterMonth(int year) {
		int month = (easterCalculation(year)) / 31;
		return Month.month(month);
	}

	static int easterDay(int year) {
		return (easterCalculation(year) % 31) + 1;
	}

	static int easterCalculation(int year) {
		int a = year % 19;
		int b = year / 100;
		int c = year % 100;
		int d = b / 4;
		int e = b % 4;
		int f = (b + 8) / 25;
		int g = (b - f + 1) / 3;
		int h = (19 * a + b - d - g + 15) % 30;
		int i = c / 4;
		int k = c % 4;
		int L = (32 + 2 * e + 2 * i - h - k) % 7;
		int m = (a + 11 * h + 22 * L) / 451;
		return h + L - 7 * m + 114;
	}
	
	static int dayNumberInYear(int day, Month month, int year) {
		int dayNumber = day;
		for (int i = 1; i <=month.number()-1; i++) {
			dayNumber = dayNumber + numberOfDaysInMonth(year, Month.month(i));
		}
		return dayNumber;
	}

	static int calculateMonth(int daysInMonth, int dayNumberInYear) {
		if
		(dayNumberInYear > daysInMonth) {
			dayNumberInYear = dayNumberInYear - daysInMonth;
		}
		return dayNumberInYear;
	}
	
	static Month monthInYearOfDayNumber(int dayNumber, int year) {
		int dayNumberInYear = dayNumber;
		int month = 1;
		if (isLeapYear(year) && !(dayNumberInYear < 60)) {
			dayNumberInYear--;
		}
		for (int i = 1; i<=12; i++) {
			if (dayNumberInYear > numberOfDaysInMonth(year, Month.month(i))) {
				dayNumberInYear = dayNumberInYear - numberOfDaysInMonth(year, Month.month(i));
				month++;
			}
		}
		return Month.month(month);
	}

	static int dayInMonthOfDayNumber(int dayNumber, int year) {
		int dayNumberInYear = dayNumber;
		for (int i = 1; i<=12; i++) {
			if (dayNumberInYear > numberOfDaysInMonth(year, Month.month(i))) {
				dayNumberInYear = dayNumberInYear - numberOfDaysInMonth(year, Month.month(i));
			}
		}
		return	dayNumberInYear;
	}

	static void showHolyDays(int year) {
		int easterDay = dayNumberInYear(easterDay(year), easterMonth(year), year); //separate functions showCarnival, showWhitsuntide, show Ascensionday
		int carnivalStart = easterDay - 49;
		System.out.println("Carnival takes place from ");
		System.out.print(dayInMonthOfDayNumber(carnivalStart, year));
		System.out.print(" to ");
		int carnivalEnd = carnivalStart + 2;
		System.out.print(dayInMonthOfDayNumber(carnivalEnd, year));
		System.out.println(monthInYearOfDayNumber(carnivalStart, year));
		int whitsuntide = easterDay + 49;
		System.out.println("Whitsuntide takes place on ");
		System.out.print(dayInMonthOfDayNumber(whitsuntide, year));
		System.out.println(monthInYearOfDayNumber(whitsuntide, year));
		int ascensionDay = whitsuntide - 10;
		System.out.println("Ascension Day takes place on ");
		System.out.print(dayInMonthOfDayNumber(ascensionDay, year));
		System.out.println(monthInYearOfDayNumber(ascensionDay, year));
	}

	public static void main(String[] arguments) {
		System.out.println("Insert a year to get the dates of holy days based on Easter");
		Scanner input = new Scanner(System.in);
		int year = input.nextInt();
		showHolyDays(year);
		input.close();
	}
}