package nl.ru.ai.p4ai.exercise2;

import static nl.ru.ai.karel.Karel.*;

public class Mondriaan
{
  public static void main(String[] args)
  {
    speed(100);
     // your code here 
  }
}
