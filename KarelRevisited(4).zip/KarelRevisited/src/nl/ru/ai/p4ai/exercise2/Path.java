package nl.ru.ai.p4ai.exercise2;

import static nl.ru.ai.karel.Karel.*;

public class Path
{
  public static void main(String[] args)
  {
    map("path.map");
    speed(100);
    // your code here
  }
}
