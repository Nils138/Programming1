package nl.ru.ai.p4ai.exercise2;

import static nl.ru.ai.karel.Karel.*;

public class CatchThemAll
{

  public static void main(String[] args)
  {
    map("pokemap.map");
    speed(100);
    // Put your code here
  }

}
